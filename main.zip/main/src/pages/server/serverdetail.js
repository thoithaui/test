import React, { useState } from "react";
import ResponsivePagination from "react-responsive-pagination";
import "react-responsive-pagination/themes/bootstrap.css";
import authService from "../../services/authService";
import apiService from "../../services/apiService";
import CardCustom from "../../components/card";
import Button from "react-bootstrap/Button";
import "./server.css";

function ServerDetail() {
  const [totalServers, setTotalServers] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPage] = useState(6);
  const [size, setSize] = useState(10);
  const [servers, setServers] = useState();
  return (
    <>
      <div className="col-12">
        <div className="row">
          <div className="col-5">
            <h4 className="mt-3 mb-2">Server: 107.0.0.1</h4>
          </div>
          <div className="col-7" style={{ margin: "auto" }}>
            <Button
              className="button-in-detail"
              // onClick={() => editUser(user)}
              variant="warning"
            >
              Edit
            </Button>
            <Button
              className="button-in-detail"
              // onClick={() => editUser(user)}
              variant="danger"
            >
              Delete
            </Button>
          </div>
        </div>
        <hr className="my-1"></hr>
        <div className="row">
          <div className="col-4 col-lg-3">
            <label htmlFor="hostip" className="form-label">
              Server IP
            </label>
            <input
              type="text"
              className="form-control"
              id="hostip"
              defaultValue="107.0.0.1"
              disabled
            />
          </div>
          <div className="col-3 col-lg-1">
            <label htmlFor="port" className="form-label">
              Port
            </label>
            <input
              type="text"
              className="form-control"
              id="port"
              defaultValue="22"
            />
          </div>
          <div className="col-3 col-lg-1">
            <label htmlFor="agent" className="form-label">
              Agent
            </label>
            <input
              type="text"
              className="form-control"
              id="agent"
              defaultValue="2"
            />
          </div>
        </div>
        <hr className="my-3"></hr>
        <div className="row">
          <div className="col-5">
            <h5 className="mt-3 mb-2">Agent list</h5>
          </div>
          <div className="col-7" style={{ margin: "auto" }}>
            <Button variant="primary" className="button-in-detail">
              Add
            </Button>
          </div>
          <div className="col-12">
            <table className="table table-hover">
              <thead>
                {/* {servers != null && */}
                <tr>
                  <th>STT</th>
                  <th>Name</th>
                  <th>Config</th>
                  <th></th>
                </tr>
                {/* }
                    {servers == null &&
                        <tr><td>Không có dữ liệu</td></tr>
                    } */}
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>Metricbeat</td>
                  <td>abc</td>
                  <td>
                    <Button
                      style={{ marginLeft: "10px" }}
                      // onClick={() => editUser(user)}
                      variant="warning"
                    >
                      Edit
                    </Button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="row">
          <div className="col-5">
            <h5 className="mt-3 mb-2">Dashboard</h5>
          </div>
          <div className="col-7" style={{ margin: "auto" }}>
            <Button
              className="button-in-detail"
              // onClick={() => editUser(user)}
              variant="warning"
            >
              Edit
            </Button>
            <Button
              className="button-in-detail"
              // onClick={() => editUser(user)}
              variant="danger"
            >
              Delete
            </Button>
          </div>
          <div className="row align-items-md-stretch">
            <div className="col-md-6 mb-2">
              <div className="h-100 p-2 bg-light border rounded-3">
                <h2>Dashboard</h2>
                <p>Picture</p>
                {/* <iframe src="http://localhost:5601/app/dashboards#/view/79ffd6e0-faa0-11e6-947f-177f697178b8-ecs?embed=true&_g=(refreshInterval%3A(pause%3A!t%2Cvalue%3A60000)%2Ctime%3A(from%3Anow-15m%2Cto%3Anow))&hide-filter-bar=true" height="500px" width="100%"></iframe>
                <iframe src="http://localhost:5601/app/dashboards#/view/0e44fb00-6061-11ee-86d0-8dd7cac17096?embed=true&_g=(refreshInterval:(pause:!t,value:60000),time:(from:now-15m,to:now))&_a=()&hide-filter-bar=true" height="500px" width="100%"></iframe> */}
              </div>
            </div>
            <div className="col-md-6 mb-2">
              <div className="h-100 p-2 bg-light border rounded-3">
                <h2>Dashboard</h2>
                <p>Picture</p>
              </div>
            </div>
            <div className="col-md-6 mb-2">
              <div className="h-100 p-2 bg-light border rounded-3">
                <h2>Dashboard</h2>
                <p>Picture</p>
              </div>
            </div>
            <div className="col-md-6 mb-2">
              <div className="h-100 p-2 bg-light border rounded-3">
                <h2>Dashboard</h2>
                <p>Picture</p>
              </div>
            </div>
          </div>
        </div>
        <hr className="my-3"></hr>
      </div>

      <div style={{ margin: "20px" }}></div>
    </>
  );
}
export default ServerDetail;
