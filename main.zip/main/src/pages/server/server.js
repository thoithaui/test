import React, { useState } from "react";
import ResponsivePagination from "react-responsive-pagination";
import "react-responsive-pagination/themes/bootstrap.css";
import authService from "../../services/authService";
import apiService from "../../services/apiService";
import CardCustom from "../../components/card";
import Button from 'react-bootstrap/Button';

function Server() {
    const [totalServers, setTotalServers] = useState(1);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPage] = useState(6);
    const [size, setSize] = useState(10);
    const [servers, setServers] = useState();
    return (
        <>
            <div className="row">
                <CardCustom text={5 + ' servers'} icon="fa-server" />
                <CardCustom text="Add server" icon="fa-server" />
            </div>
            <div className="col-12">
            <table className="table table-hover">
                <thead>
                    {/* {servers != null && */}
                    <tr>
                        <th>STT</th>
                        <th>IP</th>
                        <th>Port</th>
                        <th>Number agent</th>
                        <th></th>
                    </tr>
                    {/* }
                    {servers == null &&
                        <tr><td>Không có dữ liệu</td></tr>
                    } */}
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>107.0.0.1</td>
                        <td>22</td>
                        <td>0</td>
                        <td>
                            <Button style={{marginLeft: "10px"}}
                                // onClick={() => editUser(user)} 
                                variant="success">View</Button>
                            <Button style={{marginLeft: "10px"}}
                            // onClick={() => editUser(user)} 
                            variant="warning">Edit</Button>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
            <ResponsivePagination
                current={currentPage}
                total={totalPages}
                onPageChange={setCurrentPage}
                maxWidth={8}
            />
            <div style={{ margin: "20px" }}></div>

        </>
    );
}
export default Server;