import './login.css';
import React, { useState, useEffect } from "react";
import { stringIsBlank } from "../../services/utilityService"
import apiService from '../../services/apiService';
import authService from '../../services/authService';

function Login() {
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loggedIn, setLoggedIn] = useState(authService.isAuthenticated());

  useEffect(() => {
    if(loggedIn){
      window.location.replace('/home');
    }
  });

  const handleLogin = (response) => {
    const accountInfo = {
      username: response.username,
      email: response.email,
      roles: response.roles,
      id: response.id,
    };
    authService.setAuth(response.token, accountInfo);
    setLoggedIn(true);
  };

  const handleLogout = () => {
    authService.logout();
    setLoggedIn(false);
  };

  const handleEmailValidation = (email) => {

    if (stringIsBlank(email)) {
      setEmailError("Username is required");
    }else{
      setPasswordError("");
    }
    // if (!email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/)) {
    //   setEmailError("Email Not Valid");
    //   return false;
    // }
    setEmail(email);
  };

  const handlePaswordValidation = (password) => {
    if (stringIsBlank(password)) {
      setPasswordError("Password is required");
    }else{
      setPasswordError("");
    }
    setPassword(password);
  };

  const loginSubmit = (event) => {
    
    event.preventDefault();

    if (!stringIsBlank(email) && !stringIsBlank(password)) {
      let json = JSON.stringify({
        "username": email,
        "password": password
      });
      let config = {
        headers: {
          "Content-Type": "application/json"
        }
      }

      apiService.post('api/auth/signin', json, config)
        .then((response) => {
          if (response.status === "Login successful!") {
            handleLogin(response);
            console.log(authService.getAccountInfo());

            window.location.replace('/home');

          } else {
            handleLogout();
            setLoginError("An unknown error!");
          }
        })
        .catch((error) => {
          handleLogout();
          setLoginError("Email or password incorrect!");

          // console.log(error);
          //Test
          // window.location.replace('/home');
          //End test
        });
    } else {
      setLoginError("");
      handleEmailValidation(email);
      handlePaswordValidation(password);
    }
  };
  return (
    <div className="auth-form-container">
      <form className="auth-form">
        <div className="auth-form-content">
          <h3 className="auth-form-title">SM Project</h3>
          <div className="form-group mt-3">
            <label>User name</label>
            <input
              type="text"
              required={true}
              className="form-control mt-1"
              placeholder="Enter your name"
              onChange={(event) => handleEmailValidation(event.target.value)}
            />
            <small id="emailHelp" className="text-danger form-text">
              {emailError}
            </small>
          </div>
          <div className="form-group mt-3">
            <label>Password</label>
            <input
              type="password"
              required={true}
              className="form-control mt-1"
              placeholder="Enter your password"
              onChange={(event) => handlePaswordValidation(event.target.value)}
            />
            <small id="passwordHelp" className="text-danger form-text">
              {passwordError}
            </small>
          </div>
          <div className="d-grid gap-2 mt-3">
            <input type="submit" className="btn btn-primary" value={"Login"} onClick={loginSubmit} />
          </div>
          <small id="loginHelp" className="text-danger form-text">
            {loginError}
          </small>
          <p className="forgot-password text-right mt-2">
            {/* Forgot <a href="/">password?</a> */}
          </p>
        </div>
      </form>
    </div>
  );
}
export default Login;