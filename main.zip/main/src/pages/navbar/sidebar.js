import NavItem from './navitem';
import Dropdown from './dropdown';

const itemList =[
    {
        type: 0,
        value: {
            href: "/",
            icon: "fas fa-tachometer-alt",
            name: "Dashboard"
        }
    },
    {
        type: 0,
        value: {
            href: "Server",
            icon: "fas fa-server",
            name: "Server"
        }
    },
    {
        type: 1,
        value: {
            href: "/",
            icon: "fas fa-hourglass-start",
            name: "Agent",
            subList: [
                {
                    href: "Metricbeat",
                    name: "Metricbeat"
                },
                {
                    href: "Filebeat",
                    name: "Filebeat"
                },
            ]
        }
    },
    {
        type: 0,
        value: {
            href: "UserList",
            icon: "fas fa-users",
            name: "Account"
        }
    },
];

function SideBar(props) {
    
    return (
        <div className={"dashboard-nav "+props.mobile}>
            <header>
                <a href='/' className="menu-toggle"
                    onClick={(event)=>{
                        event.preventDefault();
                        props.setMobile('');
                    }}>
                    <i className="fas fa-bars"></i>
                </a>
                <a href="/" clas="brand-logo"><span>SM Project</span></a>
            </header>
            <div className="nav-item-divider"></div>
            <nav className="dashboard-nav-list">
                {itemList.map((item, index) =>{
                    if(item.type === 0)
                    {
                        return <NavItem key={index} itemvalue = {item.value} setPage={props.setPage}/>
                    }else{
                        return <Dropdown key={index} itemvalue = {item.value} setPage={props.setPage}/>
                    }
                })
                }

                <div className="nav-item-divider"></div>
                {/* <a href="#" className="dashboard-nav-item"><i className="fas fa-sign-out-alt"></i> Logout </a> */}
            </nav>
        </div>
    )
}
export default SideBar;