
function NavItem(props) {
    return (
        <a href="/" className="dashboard-nav-item"
            onClick={(event)=>{
                event.preventDefault();
                props.setPage(props.itemvalue.href);
            }}>
            <i className={props.itemvalue.icon}></i>
            {props.itemvalue.name}
        </a>
    )
}
export default NavItem