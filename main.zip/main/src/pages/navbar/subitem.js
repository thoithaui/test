function SubItem(props) {
    return (
        <div className='dashboard-nav-dropdown-menu'>
            {props.subList.map((sub, index) =>
                <a key={index} href="/" className="dashboard-nav-dropdown-item"
                    onClick={(event) => {
                        event.preventDefault();
                        props.setPage(sub.href);
                    }
                    }
                >{sub.name}</a>)}
        </div>
    )
}
export default SubItem;
