import SubItem from "./subitem"
import React, {useState} from "react"

function Dropdown(props) {
    const [itemShow, setItemShow] = useState('');

    return (
        <div className={'dashboard-nav-dropdown '+itemShow}>
            <a href="/" className="dashboard-nav-item dashboard-nav-dropdown-toggle"
                onClick={(event)=>{
                    event.preventDefault();
                    if(itemShow === '')
                    {
                        setItemShow("show");
                    }else{
                        setItemShow('');
                    }
                }}>
                <i className={props.itemvalue.icon}></i>
                {props.itemvalue.name}
            </a>
            <SubItem subList={props.itemvalue.subList} setPage={props.setPage}/>
        </div>
    )
}
export default Dropdown