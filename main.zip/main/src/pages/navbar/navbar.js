import React, {useEffect, useState} from "react";
import NavDropdown from 'react-bootstrap/NavDropdown';
import authService from "../../services/authService";
import { useNavigate } from 'react-router-dom';

function Navbar(props) {

    const mobileScreen = window.matchMedia("(max-width: 768px )");
    const navigate = useNavigate();
    const [loggedIn, setLoggedIn] = useState(authService.isAuthenticated());
    const handleLogout = () => {
        setLoggedIn(false);
        authService.logout();
        
    };
    const userName = authService.getAccountInfo()===null?"":authService.getAccountInfo().username;
    useEffect(() => {
        if (!loggedIn) {
            // navigate('/login');
        }
    });

    return (
        <header className='dashboard-toolbar'>
            <a href="/" className="menu-toggle"
                onClick={(event) => {
                    event.preventDefault();
                    if (mobileScreen.matches) {
                        if (props.mobile === '') {
                            props.setMobile("mobile-show");
                        } else {
                            props.setMobile('');
                        }
                    } else {
                        if (props.dashboard === '') {
                            props.setDashboard('dashboard-compact');
                        } else {
                            props.setDashboard('');
                        }
                    }
                }}>
                <i className="fas fa-bars"></i>
            </a>
            <NavDropdown title={userName} id="collasible-nav-dropdown" className="user-toggle">
                <NavDropdown.Item href="#">Info</NavDropdown.Item>
                <NavDropdown.Item href="#">Notification</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#" onClick={handleLogout}>Logout</NavDropdown.Item>
            </NavDropdown>
        </header>
    )
}
export default Navbar;