import React from "react";
import './metricbeat.css'

function Metricbeat() {

    return (
        <>
            <div>Metricbeat</div>
        </>
    );
}
export default Metricbeat;