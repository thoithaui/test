import './content.css';
import React from "react";
import UserList from "../user/userlist";
import Metricbeat from '../Agent/metricbeat';
import Server from '../server/server';
import ServerDetail from '../server/serverdetail';

function SubMenu(props) {

  let content = null;

  switch (props.item) {
    case "Dashboard":
      content = <div />;
      break;
    case "Metricbeat":
      content = <Metricbeat />;
      break;
    case "UserList":
      content = <UserList />;
      break;
    case "Server":
      content = <Server />;
      break;
    case "ServerDetail":
      content = <ServerDetail />;
      break;
    case "Filebeat":
        content = <Metricbeat />;
        break;
    default:
      content = <div>Dashboard</div>;
  }

  return (
    <div className="container" >
      {content}
    </div>
  );
};

export default SubMenu;
