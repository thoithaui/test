import ModalCustom from "../../components/modal";
import React, { useState, useEffect } from "react";
import { stringIsBlank } from "../../services/utilityService";
import authService from "../../services/authService";
import apiService from "../../services/apiService";
import { getAllRoles } from "../../services/utilityService";

function AddUser(props) {
    const [role, setRole] = useState("ROLE_VIEWER");
    const [password, setPassword] = useState("");
    const [email, setEmail] = useState("");
    const [username, setUsername] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [emailError, setEmailError] = useState("");
    const [usernameError, setUsernameError] = useState("");
    const [registerError, setRegisterError] = useState("");

    const resetvalue = () => {
        setPassword("");
        setEmail("");
        setUsername("");
    }

    const handleClose = () => {
        props.setUserInfor(null);
    }

    const handleEmailValidation = (email) => {

        if (!email.match(/^\w+@samsung/)) {
            setEmailError("Email Not Valid");
        } else if (stringIsBlank(email)) {
            setEmailError("Email is required");
        } else {
            setEmailError("");
        }
        setEmail(email);
    };

    const handlePaswordValidation = (password) => {
        if (stringIsBlank(password)) {
            setPasswordError("Password is required");
        } else {
            setPasswordError("");
        }
        setPassword(password);
    };

    const handleUsernameValidation = (username) => {
        if (stringIsBlank(username)) {
            setUsernameError("User name is required");
        }
        else {
            let json = JSON.stringify({
                "username": username
            });
            let config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${authService.getToken()}`
                }
            }
            apiService.post('api/check_account', json, config)
                .then((response) => {
                    console.log(response);
                    if (response) {
                        setUsernameError("Username already exists!");
                    } else {
                        setUsernameError("");
                    }
                })
                .catch((error) => {
                    setUsernameError("Connect to server fail!");
                });
        }
        setUsername(username);
    };

    const handleOnRoleChange = (role) => {
        setRole(role);
    };

    const registerSubmit = (event) => {

        event.preventDefault();

        if (!stringIsBlank(email) && !stringIsBlank(password) && !stringIsBlank(username) 
            && stringIsBlank(usernameError) && stringIsBlank(emailError)) {
            let json = JSON.stringify({
                "username": username,
                "email": email,
                "password": password,
                "role": [role]
            });
            let config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${authService.getToken()}`
                }
            }

            apiService.post('api/manage_account/addUser', json, config)
                .then((response) => {
                    console.log(response);
                    if (response.message === "User registered successfully!") {
                        resetvalue();
                        alert("User registered successfully!");
                        props.setShow(false);
                    } else {
                        setRegisterError("An unknown error!");
                    }
                })
                .catch((error) => {
                    setRegisterError("Register user fail!");
                });
        } else {
            setRegisterError("");
            handleEmailValidation(email);
            handlePaswordValidation(password);
            handleUsernameValidation(username);
        }
    };

    const editUserSubmit = (event) => {

        event.preventDefault();

        if (!stringIsBlank(email) && stringIsBlank(emailError)) {
            let json = JSON.stringify({
                "email": email,
                "role": [role]
            });
            console.log(json);
            let config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${authService.getToken()}`
                }
            }

            apiService.put('api/manage_account/editUser/'+props.user.id, json, config)
                .then((response) => {
                    console.log(response);
                    if (response.message === "Update successfully!") {
                        resetvalue();
                        alert("Update user information successfully!");
                        props.setShow(false);
                    } else {
                        setRegisterError("An unknown error!");
                    }
                })
                .catch((error) => {
                    setRegisterError("Update user information fail!");
                });
        } else {
            setRegisterError("");
            handleEmailValidation(email);
        }
    };

    const data = <form>
        <div className="col-md-7 col-lg-12" />
        <small id="userlHelp" className="text-danger form-text">
            {registerError}
        </small>
        <div className="row g-3">
            <div className="col-12">
                <label htmlFor="username" className="form-label">Username</label>
                <input type="text" className="form-control" id="username" placeholder="Username" required
                    disabled={props.user != null}
                    defaultValue={props.user == null ? "":props.user.username}
                    onChange={(event) => handleUsernameValidation(event.target.value)} />
                <small id="userlHelp" className="text-danger form-text">
                    {usernameError}
                </small>
            </div>

            <div className="col-12">
                <label htmlFor="email" className="form-label">Email</label>
                <input type="email" className="form-control" id="email"
                    placeholder={props.user == null ? "you@samsung.com":props.user.email}
                    onChange={(event) => handleEmailValidation(event.target.value)} />
                <small id="emailHelp" className="text-danger form-text">
                    {emailError}
                </small>
            </div>

            <div className="col-12" hidden={props.user != null}>
                <label htmlFor="password" className="form-label">Password</label>
                <input type="password" className="form-control" id="password"
                    onChange={(event) => handlePaswordValidation(event.target.value)} />
                <small id="passwordHelp" className="text-danger form-text">
                    {passwordError}
                </small>
            </div>

            <div className="col-3">
                <label className="col-2 form-label">Role</label>
            </div>
            <div className="col-4">
                <input type="radio" className="form-check-input" name='role' id="role-admin" required
                    value="ROLE_ADMIN"
                    defaultChecked={props.user != null && getAllRoles(props.user.roles)==="ROLE_ADMIN"}
                    onChange={(e) => handleOnRoleChange(e.target.value)} />
                <label className="form-check-label" htmlFor="role-admin">&nbsp; Admin</label>
            </div>

            <div className="col-4">
                <input type="radio" className="form-check-input" name='role' id="role-viewer" required
                    // defaultChecked
                    defaultChecked={props.user != null?getAllRoles(props.user.roles)==="ROLE_VIEWER":true}
                    value="ROLE_VIEWER"
                    onChange={(e) => handleOnRoleChange(e.target.value)} />
                <label className="form-check-label" htmlFor="role-viewer">&nbsp; Viewer</label>
            </div>
        </div>
    </form>

    return (
        <ModalCustom show={props.show} setShow={props.setShow} data={data} 
        title={props.user != null?"Edit user":"Add user"} 
        handlePrimary={props.user != null?editUserSubmit:registerSubmit}
        handleClose={handleClose} />
    )
}
export default AddUser;