import React, { useState, useEffect } from "react";
import ResponsivePagination from "react-responsive-pagination";
import "react-responsive-pagination/themes/bootstrap.css";
import "./userlist.css";
import CardCustom from "../../components/card";
import authService from "../../services/authService";
import apiService from "../../services/apiService";
import AddUser from "./adduser";
import { getAllRoles } from "../../services/utilityService";
import Button from 'react-bootstrap/Button';
import { useNavigate } from 'react-router-dom';

function UserList() {
  const [totalUsers, setTotalUsers] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPage] = useState();
  const [size, setSize] = useState(10);
  const [users, setUsers] = useState();
  const [show, setShow] = useState(false);
  const [userInfor, setUserInfor] = useState();
  const navigate = useNavigate();

  const editUser = (user) => {
    setUserInfor(user);
    setShow(true);
  }

  useEffect(() => {
    if (authService.getToken !== null) {
      let config = {
        headers: {
          Authorization: `Bearer ${authService.getToken()}`
        },
      };

      apiService.get('api/manage_account/viewAllUsers?page=' + currentPage + '&size='+size, config)
        .then((response) => {
          // console.log(response);
          setUsers(response.users);
          setCurrentPage(response.currentPage);
          setTotalPage(response.totalPages);
          setTotalUsers(response.totalItems);
        })
        .catch((error) => {
          if(error.response.status === 401)
          {
            authService.logout();
            navigate('/login');
          }else{
            console.log(error);
          }
        });
    }
  },[show,navigate,currentPage, size]);

  // console.log(Object.entries(users))

  return (
    <>
      {
        show && <AddUser show={show} setShow={setShow} user = {userInfor} setUserInfor ={setUserInfor}/>
      }
      <div className="row">
        <CardCustom text={totalUsers + ' users'} icon="fa-users" />
        <CardCustom text="Add user" icon="fa-user" setShow={setShow} />
      </div>
      <table className="table table-hover">
        <thead>
          {users != null &&
            <tr>
              <th>STT</th>
              <th>User name</th>
              <th>Email</th>
              <th>Roles</th>
              <th></th>
            </tr>
          }
          {users == null &&
            <tr><td>Không có dữ liệu</td></tr>
          }
        </thead>
        <tbody>
          {
            users != null && users.map((user, index) =>
              <tr key={index}>
                <td>{index+1}</td>
                <td>{user.username}</td>
                <td>{user.email}</td>
                <td>{getAllRoles(user.roles)}</td>
                <td><Button onClick={()=>editUser(user)} variant="warning">Edit</Button></td>
              </tr>
            )
          }
        </tbody>
      </table>
      <ResponsivePagination
        current={currentPage}
        total={totalPages}
        onPageChange={setCurrentPage}
        maxWidth={8}
      />
      <div style={{margin: "20px"}}></div>
    </>
  );
}
export default UserList;
