import React, { useState} from "react";
import SideBar from "../navbar/sidebar";
import Container from 'react-bootstrap/Container';
import NavbarCustom from '../navbar/navbar';
import Content from "../content/content";
import '../navbar/navbar.css';
import './home.css';

function Home() {
    const [mobile, setMobile] = useState('');
    const [page, setPage] = useState('Metricbeat');
    const [dashboard, setDashboard] = useState('');

    return (
        <Container fluid>
            <div className={"dashboard " + dashboard}>
                <SideBar mobile={mobile} setMobile={setMobile} page={page} setPage={setPage}/>
                <div className='dashboard-app'>
                    <NavbarCustom mobile={mobile} setMobile={setMobile} dashboard={dashboard} setDashboard={setDashboard} />
                    <div className='dashboard-content'>
                        <Content item={page} />
                    </div>
                </div>
            </div>
        </Container>
        
    );
}

export default Home;