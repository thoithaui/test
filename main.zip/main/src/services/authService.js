const authService = {
    // save account to sessionStorage
    setAuth: (token, accountInfo) => {
      sessionStorage.setItem('token', token);
      sessionStorage.setItem('accountInfo', JSON.stringify(accountInfo));
    },
  
    getToken: () => {
      return sessionStorage.getItem('token');
    },
  
    getAccountInfo: () => {
      const accountInfo = sessionStorage.getItem('accountInfo');
      return accountInfo ? JSON.parse(accountInfo) : null;
    },
  
    // Check user login
    isAuthenticated: () => {
      return !!sessionStorage.getItem('token');
    },
  
    logout: () => {
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('accountInfo');
    },
  };
  
  export default authService;