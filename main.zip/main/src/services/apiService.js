import axios from 'axios';

const BASE_URL =
    // 'http://107.98.78.176:8000'; //Wifi
    'http://107.98.38.217:8000'; //Lan

const apiService = {
    get: async (endpoint, config, params = {}) => {
        try {
            const response = await axios.get(`${BASE_URL}/${endpoint}`, config, { params });
            return response.data;
        } catch (error) {
            throw error;
        }
    },

    post: async (endpoint, data = {}, config) => {
        try {
            const response = await axios.post(`${BASE_URL}/${endpoint}`, data, config);
            return response.data;
        } catch (error) {
            throw error;
        }
    },

    put: async (endpoint, data = {}, config) => {
        try {
            const response = await axios.put(`${BASE_URL}/${endpoint}`, data, config);
            return response.data;
        } catch (error) {
            throw error;
        }
    },

    delete: async (endpoint, data = {}, config) => {
        try {
            const response = await axios.delete(`${BASE_URL}/${endpoint}`, data, config);
            return response.data;
        } catch (error) {
            throw error;
        }
    },
};

export default apiService;
