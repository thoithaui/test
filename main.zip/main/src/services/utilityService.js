import { parsePath } from "react-router-dom";

export function stringIsBlank(string) {
    if (string === null || string.match(/^ *$/) !== null) {
        return true;
    }
    return false;
}

export function getAllRoles(roles) {
    let roleString = "";
    if (roles != null) {
        roles.map((role, index) => {
            if (index > 0) {
                roleString += ", "
            }
            roleString += role.name
        })
    }
    return roleString;
}