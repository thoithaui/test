import React, { useEffect, useState } from 'react';
const puppeteer = require('puppeteer');

function App() {
  const [screenshotUrl, setScreenshotUrl] = useState('');

  useEffect(() => {
    (async () => {
      const browser = await puppeteer.launch();
      const page = await browser.newPage();
      const urlToCapture = 'https://example.com'; // Đường dẫn URL của trang web cần chụp
      await page.goto(urlToCapture);
      const screenshotBuffer = await page.screenshot();
      const screenshotDataUrl = `data:image/png;base64,${screenshotBuffer.toString('base64')}`;
      setScreenshotUrl(screenshotDataUrl);
      await browser.close();
    })();
  }, []);

  return (
    <div>
      {screenshotUrl && <img src={screenshotUrl} alt="Ảnh screenshot" />}
    </div>
  );
}

export default App;
