import React from "react";

function TableComponent(props) {
  return (
    <>
      <table className="table table-hover">
        <thead>
          <tr>
            <th>#</th>
            {Array.from({ length: 4 }).map((_, index) => (
              <th key={index}>Table heading</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {props.users.map((user, index) => (
            <tr key={index}>
              <td>{index}</td>
              <td>{user.username}</td>
              <td>{user.email}</td>
              <td>{user.roles}</td>
            </tr>
          ))}

        </tbody>
      </table>
    </>
  );
}
export default TableComponent;
