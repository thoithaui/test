var socket = new WebSocket("ws://localhost:8000/ssh");

socket.onopen = function(event) {
    var connectRequest = {
        username: "quocdaingo",
        password: "fouQHP96",
        hostname: "107.98.39.6",
        port: 22
    };

    socket.send(JSON.stringify(connectRequest));
};

socket.onmessage = function(event) {
    console.log(event.data);
};

socket.onclose = function(event) {
    console.log("Connection closed");
};

function sendCommand(command) {
    socket.send(command);
}

function disconnect() {
    socket.close();
}