import React from "react";

function CardCustom(props) {
    const handleClose = () => {
        props.setShow(true);
      }
    return (
        <div className="col-xl-2 col-md-4 col-sm-5 col-6 mb-4"
            onClick={props.text === "Add user"?handleClose:null}>
            <div className="card border-left-primary shadow">
                <div className="card-body">
                    <div className="row no-gutters align-items-center">
                        <div className="col mr-2">
                            <div className="h5 mb-0 font-weight-bold text-green-800">{props.text}</div>
                        </div>
                        <div className="col-auto">
                            <i className={'fas '+props.icon+' fa-2x text-gray-300'}></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default CardCustom;
